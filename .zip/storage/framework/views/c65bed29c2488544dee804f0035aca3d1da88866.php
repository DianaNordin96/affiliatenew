
<?php $__env->startSection('headScript'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Purchase Item For <?php echo e($referenceNo); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Purchase History</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-lg-5">
                    <div class="card card-warning">
                        <div class="card-header">
                            <h3 class="card-title">Customer Details</h3>

                            
                        </div>
                        <div class="card-body">
                           <?php $__currentLoopData = $customerDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <p><b>Name : <?php echo e($customer->name); ?></b></p>
                               <p><b>Phone : <?php echo e($customer->phone); ?></b></p>
                               <p><b>Address #1 : <?php echo e($customer->address); ?></b></p>
                               <p><b>Address #2 : <?php echo e($customer->address_two); ?></b></p>
                               <p><b>Address #3 : <?php echo e($customer->address_three); ?></b></p>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!-- /.card-body -->
                    </div>
                </div>

                <div class="col-lg-7">
                    <div class="card">
                        <div class="card-body">
                            <!-- <h3 class="card-title">View Employee</h3> -->
                            <a href="<?php echo e(url('/view-order')); ?>"
                                class="btn btn-warning"><i class="fa fa-angle-left"></i>
                                Go Back</a>
                            <br /><br />


                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Image</th>
                                        <th>Product Name</th>
                                        <th>Price (RM) /each</th>
                                        <th>Quantity</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <div class="col-sm-3 hidden-xs"><img
                                                        src="/imageUploaded/<?php echo e($product->product_image); ?>" width="100"
                                                        height="100" class="img-responsive" /></div>
                                            </td>
                                            <td><?php echo e($product->product_name); ?></td>
                                            <td><?php echo e($product->price_shogun); ?></td>
                                            <td><?php echo e($product->quantity); ?></td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div><!-- /.container-fluid -->

    </section>
    <!-- /.content -->
</div>
<!-- /.card -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(function () {
        $("#example1").DataTable({
            "responsive": true,
            "autoWidth": false,
        });
        $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true,
        });
    });

    document.getElementById("view-order").className = "nav-link active";

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\affiliate\resources\views/admin/view-order-item.blade.php ENDPATH**/ ?>