
<?php $__env->startSection('content'); ?>

<?php $__env->startSection('headScript'); ?>
    <style>
        .grid-container {
            display: grid;
            grid-template-columns: auto auto auto;
            background-color: #2196F3;
            padding: 10px;
        }

        .grid-item {
            background-color: rgba(255, 255, 255, 0.8);
            border: 1px solid rgba(0, 0, 0, 0.8);
            padding: 20px;
            font-size: 30px;
            text-align: center;
        }

    </style>
<?php $__env->stopSection(); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Products</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('DamioDashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Products</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

        <!-- Default box -->
        <div class="card card-solid">
            <div class="card-body pb-0">
                <div class="row">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-sm-6 col-md-4">  
                            <div class="card bg-light">
                                <div class="card-body pt-0">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <br />
                                            <img class="img-fluid" style="display: block;margin-left: auto;margin-right: auto; height:100px" src="/imageUploaded/<?php echo e($product->product_image); ?>" />
                                        <br />
                                            <div style="text-align:center">
                                                <?php echo e($product->product_name); ?>

                                                <br />
                                                <?php echo e($product->product_description); ?>

                                                <br />
                                                <b>RM <?php echo e($product->price_damio); ?></b>
                                                <br />
                                                <b style="color : blue">Commission : RM <?php echo e($product->product_price - $product->price_damio); ?> /each</b>
                                            </div>
                                        </div>

                                        <div class="col-12">
                                            <br />
                                            <button type="button" class="btn btn-block btn-outline-info" onclick="window.location='<?php echo e(url('addToCartDamio/'.$product->id)); ?>'"> Add to cart</button>
                                        </div>
                                    </div>
                                </div>
                                
                                         
                            </div>
                            &nbsp;&nbsp;&nbsp;
                       
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>

</div>
<!-- /.card -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(function() {
        $("#example1").DataTable({
            "responsive": true,
            "autoWidth": false,
        });
        $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true,
        });
    });

    document.getElementById("products").className = "nav-link active";

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.damio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\affiliate\resources\views/damio/restock.blade.php ENDPATH**/ ?>