<div class="title m-b-md">
    You cannot access this page! This is for only '<?php echo e($role); ?>'"
</div><?php /**PATH C:\laragon\www\affiliate\resources\views/unauthorized.blade.php ENDPATH**/ ?>