<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mIinwVvBTZRufU54',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PupQ2hp9CwmAGgIm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::14q34ESZ0xcL1Cv5',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/reset' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.request',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/email' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.email',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/confirm' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.confirm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tlyk0wBr66chvxht',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/manageAgent' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manageAgent',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/manageAgent/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manageAgent.create',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/manageAgent/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manageAgent.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/manageProduct' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manageProduct',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/manageProduct/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manageProduct.create',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/manageProduct/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manageProduct.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/view-order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'view-order',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/customers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QJjVmOtrukn5rpw5',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profile-admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fiObvCVxFwMdzBj6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profile-update-admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XjoAZqR399Eclq85',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/change-password-admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ji3Q9kv8qqNaS4xG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ShogunDashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ShogunDashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/product-shogun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manageStock',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/downline-shogun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manageDownline',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profile-shogun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EXqKxpNnCKg1EoiO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profileShogun-update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'profile.update.shogun',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/change-password-shogun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WzCo5ikKKM8Ngban',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/shogun-cart' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qtepkoTAbbUtnsAp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-cartShogun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gtxfneLiEd6fTyp7',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/remove-from-cartShogun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jl52rGyHGXsWQZpQ',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/checkout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oCmNqiaqwa8EiDdA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/statusShogun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'statusShogun',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/callbackShogun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'callbackShogun',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/purchase-history-shogun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'purchase-history',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/customers-shogun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hC6H3JNWBkqpiKED',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/customers-shogun-add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::V8ffMpFbJPrIHsoD',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/customers-shogun-update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EZTxbspg4E9ji0kN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/commission-shogun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::d2g3GiiGhu3DiZsm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/commission-shogun-withdrawal' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MLIUhJEOHCifP3Ne',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/DamioDashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kPG8I6jB9uavLDEl',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/product-damio' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::D4N1ocJXuIBhkclY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/downline-damio' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UIU6UORcBQ0QQhVi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profile-damio' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6XQA52j649vtlAx8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profileDamio-update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dnYQaDjcic2JrTZC',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/change-password-damio' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WWvzKpyBZCs0upkm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/damio-cart' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PS5fnJbT8zMVAn77',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-cartDamio' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PXA71fuQeJp6mtrl',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/remove-from-cartDamio' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qsBddjmTuIf8vSY0',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/checkout-damio' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OE8WvjkklZD4rtnt',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/statusDamio' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HAKEbIfQDMlwPGbu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/callbackDamio' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OqOLjpQimP1c8bTu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/purchase-history-damio' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GR7y09LLRUEdUpAt',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/customers-damio' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SGKpSOL2QgLpoe4B',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/customers-damio-add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6qBXwIJNMuBGJkKJ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/customers-damio-update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rhr2uTp6BsmHRHpf',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/commission-damio' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Fo9a9A7IOyOOHzNW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/commission-damio-withdrawal' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KwzwvjvwQzVCPTBE',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/MerchantDashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8OwafhNEaob5iHBj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/product-merchant' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tWA17YzZ8lCeZPvU',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/downline-merchant' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Je0q80ys6WLep6b8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profile-merchant' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mpSpJASCPVhfQJBI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profileMerchant-update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PWkDOJpOBq4mDPIg',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/change-password-merchant' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gdkotkxg9rF809eA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/merchant-cart' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TOGe8y4G6vkRwN3J',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-cartMerchant' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e2gJ5p7mmSgDigck',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/remove-from-cartMerchant' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DbTxgioYsXYtXiyG',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/checkout-merchant' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yP0h7gT8nYzt9Ev0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/statusMerchant' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AN8hcnvsm5U2zqwS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/callbackMerchant' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oIB1gxx9J3p7AhVG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/purchase-history-merchant' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AxEVi7XUQKbPMUqt',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/customers-merchant' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CtlX42QjZQHufr3w',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/customers-merchant-add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::r957wSfq4boVWIBN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/customers-merchant-update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oiGAaf1y5VlxQrNj',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/commission-merchant' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::n90vSb3qoYvO3WqC',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/commission-merchant-withdrawal' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VK0E2evZqIEdr8Lv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/DropshipDashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rGcsnfRYzRckSScx',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/product-dropship' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4vYGmRpN8Iok7FXd',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profile-dropship' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QeTaCX7pzCFOVEkl',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profileDropship-update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PBhgTqVmdwu0R66p',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/change-password-dropship' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ExUfQhMvYwHYg4TT',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dropship-cart' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4D757rf9k002cbOx',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-cartDropship' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::z67J1JWunmrpJQXa',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/remove-from-cartDropship' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8rGUCNicniqMtLVm',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/checkout-dropship' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eDBbON1YoRV1Ukmh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/statusDropship' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5lwxOUEKYbwI2Whs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/callbackDropship' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uwnQ51XHqRsTubkQ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/purchase-history-dropship' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TXOMqkkNj9NuuNO4',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/customers-dropship' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Vv8rq1ddBNV3rbBR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/customers-dropship-add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qb6EnIFVyF5xDbTk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/customers-dropship-update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mlnkNMPheUSS6oYb',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/commission-dropship' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xirVB2ohmunHmuB1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/commission-dropship-withdrawal' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::djLQ9QFxDeKoRJWS',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/MasterDashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::44zA41Jkj1GLWV37',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/master-viewAgent' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uMC1rhDqE0T7MpKj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/master-commission' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mQpuKWa1URXj3E4k',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registerDownline' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JA2uK787uDe6Elrp',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registerDownline-info' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2Jnmrz4oR313laXP',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/password/reset/([^/]++)(*:31)|/ma(?|nage(?|Agent/(?|delete/([^/]++)(*:75)|([^/]++)/([^/]++)(*:99))|Product/delete/([^/]++)(*:130)|Downline(?|Shogun/([^/]++)/([^/]++)(*:173)|Damio/([^/]++)/([^/]++)(*:204)|Merchant/([^/]++)/([^/]++)(*:238)))|ster\\-commission\\-(?|approve/([^/]++)(*:285)|decline/([^/]++)(*:309)))|/view\\-(?|order\\-item/([^/]++)(*:349)|purchased\\-product(?|/([^/]++)(*:387)|\\-(?|d(?|amio/([^/]++)(*:417)|ropship/([^/]++)(*:441))|merchant/([^/]++)(*:467))))|/a(?|ddToCart(?|Shogun/([^/]++)(*:509)|D(?|amio/([^/]++)(*:534)|ropship/([^/]++)(*:558))|Merchant/([^/]++)(*:584))|pproveDownline\\-(?|shogun/([^/]++)(*:627)|damio/([^/]++)(*:649)|merchant/([^/]++)(*:674)))|/customers\\-(?|shogun\\-delete/([^/]++)(*:722)|d(?|amio\\-delete/([^/]++)(*:755)|ropship\\-delete/([^/]++)(*:787))|merchant\\-delete/([^/]++)(*:821))|/declineDownline\\-(?|shogun/([^/]++)(*:866)|damio/([^/]++)(*:888)|merchant/([^/]++)(*:913))|/registerDownline/([^/]++)(*:948))/?$}sDu',
    ),
    3 => 
    array (
      31 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.reset',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      75 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PjMrvKid3cSq84pQ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      99 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9IB6HU9AEiM9t8pC',
          ),
          1 => 
          array (
            0 => 'role',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      130 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manageProduct.delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      173 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vmexPuNhpUYiNLPR',
          ),
          1 => 
          array (
            0 => 'role',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      204 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zCDmYljWqoOW9VAu',
          ),
          1 => 
          array (
            0 => 'role',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      238 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0dBqa83pLIi28CZT',
          ),
          1 => 
          array (
            0 => 'role',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      285 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yz4718x969q91bCD',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      309 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3hUQGO8I5mTqbput',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      349 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fJjv72wPxyucDTn7',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      387 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bEcafI26C50gEiw9',
          ),
          1 => 
          array (
            0 => 'orderID',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      417 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QXRc6fs2OuRqI3bd',
          ),
          1 => 
          array (
            0 => 'orderID',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      441 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xLY9dVqdj5W7i6Rj',
          ),
          1 => 
          array (
            0 => 'orderID',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      467 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::S1INjs2nrYrkCkLE',
          ),
          1 => 
          array (
            0 => 'orderID',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      509 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Gkb6hiMSLgeUls6D',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      534 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZbmVeeY2ho4tC9zJ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      558 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KjasvwLiW09ugANV',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      584 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MzXvTki12qawSQ0X',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      627 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f322SbY4MHujvdoE',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      649 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vj3NcqJKT57saGui',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      674 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::l4bNlWYBq5OimK1r',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      722 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SBHGSz0z7iCcyfgp',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      755 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gGXr7MbfHYXf8iJZ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      787 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2kMFsdWgyXu6hdH0',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      821 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LBMF0zb6qiMKJTEK',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      866 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fHFZe6pvs50GMedH',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      888 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9vjTOQlZtzWMJknN',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      913 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uCCBdmlKeM75Jjxv',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      948 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mwAxFcFLpOdBFb5K',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::mIinwVvBTZRufU54' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RedirectController@redirect',
        'controller' => 'App\\Http\\Controllers\\RedirectController@redirect',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::mIinwVvBTZRufU54',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@showLoginForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@showLoginForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::PupQ2hp9CwmAGgIm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::PupQ2hp9CwmAGgIm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@showRegistrationForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@showRegistrationForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::14q34ESZ0xcL1Cv5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@register',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@register',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::14q34ESZ0xcL1Cv5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.request' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showLinkRequestForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showLinkRequestForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.email' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.email',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.reset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/reset/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@showResetForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@showResetForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@reset',
        'controller' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@reset',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'password.confirm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/confirm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@showConfirmForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@showConfirmForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'password.confirm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tlyk0wBr66chvxht' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/confirm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@confirm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@confirm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::tlyk0wBr66chvxht',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\DashboardController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'manageAgent' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'manageAgent',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ManageAgentController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ManageAgentController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'manageAgent',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'manageAgent.create' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'manageAgent/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ManageAgentController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\ManageAgentController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'manageAgent.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::PjMrvKid3cSq84pQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'manageAgent/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ManageAgentController@Delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\ManageAgentController@Delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::PjMrvKid3cSq84pQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'manageAgent.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'manageAgent/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ManageAgentController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\ManageAgentController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'manageAgent.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9IB6HU9AEiM9t8pC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'manageAgent/{role}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ManageAgentController@changeRole',
        'controller' => 'App\\Http\\Controllers\\Admin\\ManageAgentController@changeRole',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::9IB6HU9AEiM9t8pC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'manageProduct' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'manageProduct',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ManageProductController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ManageProductController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'manageProduct',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'manageProduct.create' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'manageProduct/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ManageProductController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\ManageProductController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'manageProduct.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'manageProduct.delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'manageProduct/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ManageProductController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\ManageProductController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'manageProduct.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'manageProduct.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'manageProduct/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ManageProductController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\ManageProductController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'manageProduct.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'view-order' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'view-order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ManageOrderController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ManageOrderController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'view-order',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::fJjv72wPxyucDTn7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'view-order-item/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ManageOrderController@viewItem',
        'controller' => 'App\\Http\\Controllers\\Admin\\ManageOrderController@viewItem',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::fJjv72wPxyucDTn7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::QJjVmOtrukn5rpw5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'customers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::QJjVmOtrukn5rpw5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::fiObvCVxFwMdzBj6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'profile-admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProfileController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProfileController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::fiObvCVxFwMdzBj6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XjoAZqR399Eclq85' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'profile-update-admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProfileController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProfileController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::XjoAZqR399Eclq85',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ji3Q9kv8qqNaS4xG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'change-password-admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProfileController@changePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProfileController@changePassword',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ji3Q9kv8qqNaS4xG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'ShogunDashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ShogunDashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Shogun\\DashboardController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'ShogunDashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'manageStock' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'product-shogun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
          3 => 'shogun',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\ManageStockController@index',
        'controller' => 'App\\Http\\Controllers\\Shogun\\ManageStockController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'manageStock',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'manageDownline' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'downline-shogun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\ManageDownlineController@index',
        'controller' => 'App\\Http\\Controllers\\Shogun\\ManageDownlineController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'manageDownline',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::vmexPuNhpUYiNLPR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'manageDownlineShogun/{role}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\ManageDownlineController@changeRole',
        'controller' => 'App\\Http\\Controllers\\Shogun\\ManageDownlineController@changeRole',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::vmexPuNhpUYiNLPR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::EXqKxpNnCKg1EoiO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'profile-shogun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\ProfileController@index',
        'controller' => 'App\\Http\\Controllers\\Shogun\\ProfileController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::EXqKxpNnCKg1EoiO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'profile.update.shogun' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'profileShogun-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\ProfileController@update',
        'controller' => 'App\\Http\\Controllers\\Shogun\\ProfileController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'profile.update.shogun',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::WzCo5ikKKM8Ngban' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'change-password-shogun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\ProfileController@changePassword',
        'controller' => 'App\\Http\\Controllers\\Shogun\\ProfileController@changePassword',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::WzCo5ikKKM8Ngban',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qtepkoTAbbUtnsAp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'shogun-cart',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\CartController@cart',
        'controller' => 'App\\Http\\Controllers\\Shogun\\CartController@cart',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::qtepkoTAbbUtnsAp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Gkb6hiMSLgeUls6D' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'addToCartShogun/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\CartController@addToCart',
        'controller' => 'App\\Http\\Controllers\\Shogun\\CartController@addToCart',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Gkb6hiMSLgeUls6D',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::gtxfneLiEd6fTyp7' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'update-cartShogun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\CartController@update',
        'controller' => 'App\\Http\\Controllers\\Shogun\\CartController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::gtxfneLiEd6fTyp7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::jl52rGyHGXsWQZpQ' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'remove-from-cartShogun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\CartController@remove',
        'controller' => 'App\\Http\\Controllers\\Shogun\\CartController@remove',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::jl52rGyHGXsWQZpQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::oCmNqiaqwa8EiDdA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'checkout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\CartController@checkout',
        'controller' => 'App\\Http\\Controllers\\Shogun\\CartController@checkout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::oCmNqiaqwa8EiDdA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'statusShogun' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'statusShogun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\CartController@paymentStatus',
        'controller' => 'App\\Http\\Controllers\\Shogun\\CartController@paymentStatus',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'statusShogun',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'callbackShogun' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'callbackShogun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\CartController@callback',
        'controller' => 'App\\Http\\Controllers\\Shogun\\CartController@callback',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'callbackShogun',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'purchase-history' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'purchase-history-shogun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\PurchaseController@index',
        'controller' => 'App\\Http\\Controllers\\Shogun\\PurchaseController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'purchase-history',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bEcafI26C50gEiw9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'view-purchased-product/{orderID}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\PurchaseController@viewPurchase',
        'controller' => 'App\\Http\\Controllers\\Shogun\\PurchaseController@viewPurchase',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::bEcafI26C50gEiw9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hC6H3JNWBkqpiKED' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'customers-shogun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\CustomerController@index',
        'controller' => 'App\\Http\\Controllers\\Shogun\\CustomerController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::hC6H3JNWBkqpiKED',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::V8ffMpFbJPrIHsoD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'customers-shogun-add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\CustomerController@create',
        'controller' => 'App\\Http\\Controllers\\Shogun\\CustomerController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::V8ffMpFbJPrIHsoD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::EZTxbspg4E9ji0kN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'customers-shogun-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\CustomerController@update',
        'controller' => 'App\\Http\\Controllers\\Shogun\\CustomerController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::EZTxbspg4E9ji0kN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::SBHGSz0z7iCcyfgp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'customers-shogun-delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\CustomerController@delete',
        'controller' => 'App\\Http\\Controllers\\Shogun\\CustomerController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::SBHGSz0z7iCcyfgp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::d2g3GiiGhu3DiZsm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'commission-shogun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\CommissionController@index',
        'controller' => 'App\\Http\\Controllers\\Shogun\\CommissionController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::d2g3GiiGhu3DiZsm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::MLIUhJEOHCifP3Ne' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'commission-shogun-withdrawal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\CommissionController@withdraw',
        'controller' => 'App\\Http\\Controllers\\Shogun\\CommissionController@withdraw',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::MLIUhJEOHCifP3Ne',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::f322SbY4MHujvdoE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'approveDownline-shogun/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\ManageDownlineController@approve',
        'controller' => 'App\\Http\\Controllers\\Shogun\\ManageDownlineController@approve',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::f322SbY4MHujvdoE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::fHFZe6pvs50GMedH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'declineDownline-shogun/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'shogun',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Shogun\\ManageDownlineController@decline',
        'controller' => 'App\\Http\\Controllers\\Shogun\\ManageDownlineController@decline',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::fHFZe6pvs50GMedH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::kPG8I6jB9uavLDEl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'DamioDashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Damio\\DashboardController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::kPG8I6jB9uavLDEl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::D4N1ocJXuIBhkclY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'product-damio',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\ManageStockController@index',
        'controller' => 'App\\Http\\Controllers\\Damio\\ManageStockController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::D4N1ocJXuIBhkclY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::UIU6UORcBQ0QQhVi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'downline-damio',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\ManageDownlineController@index',
        'controller' => 'App\\Http\\Controllers\\Damio\\ManageDownlineController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::UIU6UORcBQ0QQhVi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zCDmYljWqoOW9VAu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'manageDownlineDamio/{role}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\ManageDownlineController@changeRole',
        'controller' => 'App\\Http\\Controllers\\Damio\\ManageDownlineController@changeRole',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::zCDmYljWqoOW9VAu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::6XQA52j649vtlAx8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'profile-damio',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\ProfileController@index',
        'controller' => 'App\\Http\\Controllers\\Damio\\ProfileController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::6XQA52j649vtlAx8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::dnYQaDjcic2JrTZC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'profileDamio-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\ProfileController@update',
        'controller' => 'App\\Http\\Controllers\\Damio\\ProfileController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::dnYQaDjcic2JrTZC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::WWvzKpyBZCs0upkm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'change-password-damio',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\ProfileController@changePassword',
        'controller' => 'App\\Http\\Controllers\\Damio\\ProfileController@changePassword',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::WWvzKpyBZCs0upkm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::PS5fnJbT8zMVAn77' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'damio-cart',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\CartController@cart',
        'controller' => 'App\\Http\\Controllers\\Damio\\CartController@cart',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::PS5fnJbT8zMVAn77',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZbmVeeY2ho4tC9zJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'addToCartDamio/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\CartController@addToCart',
        'controller' => 'App\\Http\\Controllers\\Damio\\CartController@addToCart',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ZbmVeeY2ho4tC9zJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::PXA71fuQeJp6mtrl' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'update-cartDamio',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\CartController@update',
        'controller' => 'App\\Http\\Controllers\\Damio\\CartController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::PXA71fuQeJp6mtrl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qsBddjmTuIf8vSY0' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'remove-from-cartDamio',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\CartController@remove',
        'controller' => 'App\\Http\\Controllers\\Damio\\CartController@remove',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::qsBddjmTuIf8vSY0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OE8WvjkklZD4rtnt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'checkout-damio',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\CartController@checkout',
        'controller' => 'App\\Http\\Controllers\\Damio\\CartController@checkout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::OE8WvjkklZD4rtnt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::HAKEbIfQDMlwPGbu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'statusDamio',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\CartController@paymentStatus',
        'controller' => 'App\\Http\\Controllers\\Damio\\CartController@paymentStatus',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::HAKEbIfQDMlwPGbu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OqOLjpQimP1c8bTu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'callbackDamio',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\CartController@callback',
        'controller' => 'App\\Http\\Controllers\\Damio\\CartController@callback',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::OqOLjpQimP1c8bTu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::GR7y09LLRUEdUpAt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'purchase-history-damio',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\PurchaseController@index',
        'controller' => 'App\\Http\\Controllers\\Damio\\PurchaseController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::GR7y09LLRUEdUpAt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::QXRc6fs2OuRqI3bd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'view-purchased-product-damio/{orderID}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\PurchaseController@viewPurchase',
        'controller' => 'App\\Http\\Controllers\\Damio\\PurchaseController@viewPurchase',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::QXRc6fs2OuRqI3bd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::SGKpSOL2QgLpoe4B' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'customers-damio',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\CustomerController@index',
        'controller' => 'App\\Http\\Controllers\\Damio\\CustomerController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::SGKpSOL2QgLpoe4B',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::6qBXwIJNMuBGJkKJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'customers-damio-add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\CustomerController@create',
        'controller' => 'App\\Http\\Controllers\\Damio\\CustomerController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::6qBXwIJNMuBGJkKJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::rhr2uTp6BsmHRHpf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'customers-damio-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\CustomerController@update',
        'controller' => 'App\\Http\\Controllers\\Damio\\CustomerController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::rhr2uTp6BsmHRHpf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::gGXr7MbfHYXf8iJZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'customers-damio-delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\CustomerController@delete',
        'controller' => 'App\\Http\\Controllers\\Damio\\CustomerController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::gGXr7MbfHYXf8iJZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Fo9a9A7IOyOOHzNW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'commission-damio',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\CommissionController@index',
        'controller' => 'App\\Http\\Controllers\\Damio\\CommissionController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Fo9a9A7IOyOOHzNW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::KwzwvjvwQzVCPTBE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'commission-damio-withdrawal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\CommissionController@withdraw',
        'controller' => 'App\\Http\\Controllers\\Damio\\CommissionController@withdraw',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::KwzwvjvwQzVCPTBE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::vj3NcqJKT57saGui' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'approveDownline-damio/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\ManageDownlineController@approve',
        'controller' => 'App\\Http\\Controllers\\Damio\\ManageDownlineController@approve',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::vj3NcqJKT57saGui',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9vjTOQlZtzWMJknN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'declineDownline-damio/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'damio',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\ManageDownlineController@decline',
        'controller' => 'App\\Http\\Controllers\\Damio\\ManageDownlineController@decline',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::9vjTOQlZtzWMJknN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8OwafhNEaob5iHBj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'MerchantDashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Merchant\\DashboardController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::8OwafhNEaob5iHBj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tWA17YzZ8lCeZPvU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'product-merchant',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\ManageStockController@index',
        'controller' => 'App\\Http\\Controllers\\Merchant\\ManageStockController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::tWA17YzZ8lCeZPvU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Je0q80ys6WLep6b8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'downline-merchant',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\ManageDownlineController@index',
        'controller' => 'App\\Http\\Controllers\\Merchant\\ManageDownlineController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Je0q80ys6WLep6b8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::0dBqa83pLIi28CZT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'manageDownlineMerchant/{role}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\ManageDownlineController@changeRole',
        'controller' => 'App\\Http\\Controllers\\Merchant\\ManageDownlineController@changeRole',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::0dBqa83pLIi28CZT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mpSpJASCPVhfQJBI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'profile-merchant',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\ProfileController@index',
        'controller' => 'App\\Http\\Controllers\\Merchant\\ProfileController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::mpSpJASCPVhfQJBI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::PWkDOJpOBq4mDPIg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'profileMerchant-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\ProfileController@update',
        'controller' => 'App\\Http\\Controllers\\Merchant\\ProfileController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::PWkDOJpOBq4mDPIg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::gdkotkxg9rF809eA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'change-password-merchant',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\ProfileController@changePassword',
        'controller' => 'App\\Http\\Controllers\\Merchant\\ProfileController@changePassword',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::gdkotkxg9rF809eA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::TOGe8y4G6vkRwN3J' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'merchant-cart',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\CartController@cart',
        'controller' => 'App\\Http\\Controllers\\Merchant\\CartController@cart',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::TOGe8y4G6vkRwN3J',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::MzXvTki12qawSQ0X' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'addToCartMerchant/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\CartController@addToCart',
        'controller' => 'App\\Http\\Controllers\\Merchant\\CartController@addToCart',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::MzXvTki12qawSQ0X',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::e2gJ5p7mmSgDigck' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'update-cartMerchant',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\CartController@update',
        'controller' => 'App\\Http\\Controllers\\Merchant\\CartController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::e2gJ5p7mmSgDigck',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::DbTxgioYsXYtXiyG' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'remove-from-cartMerchant',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\CartController@remove',
        'controller' => 'App\\Http\\Controllers\\Merchant\\CartController@remove',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::DbTxgioYsXYtXiyG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yP0h7gT8nYzt9Ev0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'checkout-merchant',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\CartController@checkout',
        'controller' => 'App\\Http\\Controllers\\Merchant\\CartController@checkout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::yP0h7gT8nYzt9Ev0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::AN8hcnvsm5U2zqwS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'statusMerchant',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\CartController@paymentStatus',
        'controller' => 'App\\Http\\Controllers\\Merchant\\CartController@paymentStatus',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::AN8hcnvsm5U2zqwS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::oIB1gxx9J3p7AhVG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'callbackMerchant',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\CartController@callback',
        'controller' => 'App\\Http\\Controllers\\Merchant\\CartController@callback',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::oIB1gxx9J3p7AhVG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::AxEVi7XUQKbPMUqt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'purchase-history-merchant',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\PurchaseController@index',
        'controller' => 'App\\Http\\Controllers\\Merchant\\PurchaseController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::AxEVi7XUQKbPMUqt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::S1INjs2nrYrkCkLE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'view-purchased-product-merchant/{orderID}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\PurchaseController@viewPurchase',
        'controller' => 'App\\Http\\Controllers\\Merchant\\PurchaseController@viewPurchase',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::S1INjs2nrYrkCkLE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::CtlX42QjZQHufr3w' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'customers-merchant',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\CustomerController@index',
        'controller' => 'App\\Http\\Controllers\\Merchant\\CustomerController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::CtlX42QjZQHufr3w',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::r957wSfq4boVWIBN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'customers-merchant-add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\CustomerController@create',
        'controller' => 'App\\Http\\Controllers\\Merchant\\CustomerController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::r957wSfq4boVWIBN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::oiGAaf1y5VlxQrNj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'customers-merchant-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\CustomerController@update',
        'controller' => 'App\\Http\\Controllers\\Merchant\\CustomerController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::oiGAaf1y5VlxQrNj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::LBMF0zb6qiMKJTEK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'customers-merchant-delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\CustomerController@delete',
        'controller' => 'App\\Http\\Controllers\\Merchant\\CustomerController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::LBMF0zb6qiMKJTEK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::n90vSb3qoYvO3WqC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'commission-merchant',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\CommissionController@index',
        'controller' => 'App\\Http\\Controllers\\Merchant\\CommissionController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::n90vSb3qoYvO3WqC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::VK0E2evZqIEdr8Lv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'commission-merchant-withdrawal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Merchant\\CommissionController@withdraw',
        'controller' => 'App\\Http\\Controllers\\Merchant\\CommissionController@withdraw',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::VK0E2evZqIEdr8Lv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::l4bNlWYBq5OimK1r' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'approveDownline-merchant/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\ManageDownlineController@approve',
        'controller' => 'App\\Http\\Controllers\\Damio\\ManageDownlineController@approve',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::l4bNlWYBq5OimK1r',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::uCCBdmlKeM75Jjxv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'declineDownline-merchant/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'merchant',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Damio\\ManageDownlineController@decline',
        'controller' => 'App\\Http\\Controllers\\Damio\\ManageDownlineController@decline',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::uCCBdmlKeM75Jjxv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::rGcsnfRYzRckSScx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'DropshipDashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DropshipMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Dropship\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Dropship\\DashboardController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::rGcsnfRYzRckSScx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::4vYGmRpN8Iok7FXd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'product-dropship',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DropshipMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Dropship\\ManageStockController@index',
        'controller' => 'App\\Http\\Controllers\\Dropship\\ManageStockController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::4vYGmRpN8Iok7FXd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::QeTaCX7pzCFOVEkl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'profile-dropship',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DropshipMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Dropship\\ProfileController@index',
        'controller' => 'App\\Http\\Controllers\\Dropship\\ProfileController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::QeTaCX7pzCFOVEkl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::PBhgTqVmdwu0R66p' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'profileDropship-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DropshipMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Dropship\\ProfileController@update',
        'controller' => 'App\\Http\\Controllers\\Dropship\\ProfileController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::PBhgTqVmdwu0R66p',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ExUfQhMvYwHYg4TT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'change-password-dropship',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DropshipMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Dropship\\ProfileController@changePassword',
        'controller' => 'App\\Http\\Controllers\\Dropship\\ProfileController@changePassword',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ExUfQhMvYwHYg4TT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::4D757rf9k002cbOx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dropship-cart',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DropshipMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Dropship\\CartController@cart',
        'controller' => 'App\\Http\\Controllers\\Dropship\\CartController@cart',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::4D757rf9k002cbOx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::KjasvwLiW09ugANV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'addToCartDropship/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DropshipMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Dropship\\CartController@addToCart',
        'controller' => 'App\\Http\\Controllers\\Dropship\\CartController@addToCart',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::KjasvwLiW09ugANV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::z67J1JWunmrpJQXa' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'update-cartDropship',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DropshipMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Dropship\\CartController@update',
        'controller' => 'App\\Http\\Controllers\\Dropship\\CartController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::z67J1JWunmrpJQXa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8rGUCNicniqMtLVm' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'remove-from-cartDropship',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DropshipMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Dropship\\CartController@remove',
        'controller' => 'App\\Http\\Controllers\\Dropship\\CartController@remove',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::8rGUCNicniqMtLVm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::eDBbON1YoRV1Ukmh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'checkout-dropship',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DropshipMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Dropship\\CartController@checkout',
        'controller' => 'App\\Http\\Controllers\\Dropship\\CartController@checkout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::eDBbON1YoRV1Ukmh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5lwxOUEKYbwI2Whs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'statusDropship',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DropshipMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Dropship\\CartController@paymentStatus',
        'controller' => 'App\\Http\\Controllers\\Dropship\\CartController@paymentStatus',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::5lwxOUEKYbwI2Whs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::uwnQ51XHqRsTubkQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'callbackDropship',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DropshipMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Dropship\\CartController@callback',
        'controller' => 'App\\Http\\Controllers\\Dropship\\CartController@callback',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::uwnQ51XHqRsTubkQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::TXOMqkkNj9NuuNO4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'purchase-history-dropship',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DropshipMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Dropship\\PurchaseController@index',
        'controller' => 'App\\Http\\Controllers\\Dropship\\PurchaseController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::TXOMqkkNj9NuuNO4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xLY9dVqdj5W7i6Rj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'view-purchased-product-dropship/{orderID}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DropshipMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Dropship\\PurchaseController@viewPurchase',
        'controller' => 'App\\Http\\Controllers\\Dropship\\PurchaseController@viewPurchase',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::xLY9dVqdj5W7i6Rj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Vv8rq1ddBNV3rbBR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'customers-dropship',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DropshipMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Dropship\\CustomerController@index',
        'controller' => 'App\\Http\\Controllers\\Dropship\\CustomerController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Vv8rq1ddBNV3rbBR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qb6EnIFVyF5xDbTk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'customers-dropship-add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DropshipMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Dropship\\CustomerController@create',
        'controller' => 'App\\Http\\Controllers\\Dropship\\CustomerController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::qb6EnIFVyF5xDbTk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mlnkNMPheUSS6oYb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'customers-dropship-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DropshipMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Dropship\\CustomerController@update',
        'controller' => 'App\\Http\\Controllers\\Dropship\\CustomerController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::mlnkNMPheUSS6oYb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::2kMFsdWgyXu6hdH0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'customers-dropship-delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DropshipMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Dropship\\CustomerController@delete',
        'controller' => 'App\\Http\\Controllers\\Dropship\\CustomerController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::2kMFsdWgyXu6hdH0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xirVB2ohmunHmuB1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'commission-dropship',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DropshipMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Dropship\\CommissionController@index',
        'controller' => 'App\\Http\\Controllers\\Dropship\\CommissionController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::xirVB2ohmunHmuB1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::djLQ9QFxDeKoRJWS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'commission-dropship-withdrawal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DropshipMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Dropship\\CommissionController@withdraw',
        'controller' => 'App\\Http\\Controllers\\Dropship\\CommissionController@withdraw',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::djLQ9QFxDeKoRJWS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::44zA41Jkj1GLWV37' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'MasterDashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\MasterAdminMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\MasterAdmin\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\MasterAdmin\\DashboardController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::44zA41Jkj1GLWV37',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::uMC1rhDqE0T7MpKj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'master-viewAgent',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\MasterAdminMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\MasterAdmin\\ManageAgentController@index',
        'controller' => 'App\\Http\\Controllers\\MasterAdmin\\ManageAgentController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::uMC1rhDqE0T7MpKj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mQpuKWa1URXj3E4k' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'master-commission',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\MasterAdminMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\MasterAdmin\\ManageCommissionController@index',
        'controller' => 'App\\Http\\Controllers\\MasterAdmin\\ManageCommissionController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::mQpuKWa1URXj3E4k',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yz4718x969q91bCD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'master-commission-approve/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\MasterAdminMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\MasterAdmin\\ManageCommissionController@approve',
        'controller' => 'App\\Http\\Controllers\\MasterAdmin\\ManageCommissionController@approve',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::yz4718x969q91bCD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3hUQGO8I5mTqbput' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'master-commission-decline/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\MasterAdminMiddleware',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\MasterAdmin\\ManageCommissionController@decline',
        'controller' => 'App\\Http\\Controllers\\MasterAdmin\\ManageCommissionController@decline',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::3hUQGO8I5mTqbput',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mwAxFcFLpOdBFb5K' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'registerDownline/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\ReferralController@index',
        'controller' => 'App\\Http\\Controllers\\ReferralController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::mwAxFcFLpOdBFb5K',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::JA2uK787uDe6Elrp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'registerDownline',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\ReferralController@create',
        'controller' => 'App\\Http\\Controllers\\ReferralController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::JA2uK787uDe6Elrp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::2Jnmrz4oR313laXP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'registerDownline-info',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\ReferralController@info',
        'controller' => 'App\\Http\\Controllers\\ReferralController@info',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::2Jnmrz4oR313laXP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);
